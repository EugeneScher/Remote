define([], function () {
    var InPlay = {
        enemies: enemies = [],
        playerBullets: playerBullets = [],
        enemyBullets: enemyBullets = [],
        powerUps: powerUps = []
    };
    return InPlay;
});